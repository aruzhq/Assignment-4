const mongoose = require('mongoose');

const measurementSchema = new mongoose.Schema({
    timestamp: { type: Date, required: true },
    symbol: { type: String, required: true },
    closePrice: { type: Number, required: true },
    highPrice: { type: Number },
    lowPrice: { type: Number },
    volume: { type: Number }
});

module.exports = mongoose.model('Measurement', measurementSchema);

const yahooFinance = require('yahoo-finance2').default;
const Measurement = require('../models/Measurement');

const fetchYahooFinanceData = async (symbol, date) => {
    try {
        const period1 = new Date(date);
        period1.setHours(0, 0, 0, 0);

        const period2 = new Date(date);
        period2.setDate(period2.getDate() + 1);

        const historicalData = await yahooFinance.historical(symbol, { period1, period2 });

        if (historicalData && historicalData.length > 0) {
            const data = historicalData[0];
            const measurement = new Measurement({
                timestamp: period1,
                symbol: symbol,
                closePrice: data.close,
                highPrice: data.high,
                lowPrice: data.low,
                volume: data.volume
            });

            await measurement.save();
            console.log(`Data for ${symbol} on ${period1.toISOString().split('T')[0]} saved to MongoDB`);
        } else {
            console.log(`No data available for ${symbol} on ${period1.toISOString().split('T')[0]}`);
        }
    } catch (error) {
        console.error(`Error fetching data for ${symbol} on ${date || 'today'}:`, error);
    }
};

module.exports = fetchYahooFinanceData;

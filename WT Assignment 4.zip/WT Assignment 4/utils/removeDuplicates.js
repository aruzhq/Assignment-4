const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

const Measurement = require('../models/Measurement');

const removeDuplicates = async () => {
    const duplicates = await Measurement.aggregate([
        { $group: {
            _id: { timestamp: "$timestamp", symbol: "$symbol" },
            uniqueIds: { $addToSet: "$_id" },
            count: { $sum: 1 }
        }},
        { $match: { count: { $gt: 1 } } }
    ]);

    for (const doc of duplicates) {
        doc.uniqueIds.shift(); 
        await Measurement.deleteMany({ _id: { $in: doc.uniqueIds } }); 
    }

    console.log('Duplicates removed');
    mongoose.connection.close();
};

removeDuplicates();

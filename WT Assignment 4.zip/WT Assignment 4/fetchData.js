require('dotenv').config();
const mongoose = require('mongoose');
const fetchYahooFinanceData = require('./utils/fetchYahooFinanceData');

mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

const symbols = ['AAPL', 'GOOGL', 'MSFT']; 

const fetchData = async () => {
    const days = 10; 

    for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i); 
        date.setHours(0, 0, 0, 0); 

        console.log(`Fetching data for date: ${date.toISOString().split('T')[0]}`);

        for (const symbol of symbols) {
            await fetchYahooFinanceData(symbol, date); 
        }
    }
    mongoose.connection.close();
};

fetchData();

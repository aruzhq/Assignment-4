const Measurement = require('../models/Measurement');

exports.getMeasurements = async (req, res) => {
    const { symbol, start_date, end_date } = req.query;
    const filter = { symbol };

    if (start_date && end_date) {
        filter.timestamp = {
            $gte: new Date(start_date).setHours(0, 0, 0, 0),
            $lt: new Date(end_date).setHours(23, 59, 59, 999)
        };
    }

    console.log('Filter:', filter);

    try {
        const data = await Measurement.find(filter);

        if (data.length === 0) {
            console.log('No data found for filter:', filter);
            return res.status(404).json({ message: 'No data available for the selected range' });
        }

        console.log('Data found:', data);
        res.json(data);
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).json({ message: error.message });
    }
};

exports.addMeasurement = async (req, res) => {
    const { timestamp, symbol, closePrice, highPrice, lowPrice, volume } = req.body;
    const measurement = new Measurement({ timestamp, symbol, closePrice, highPrice, lowPrice, volume });

    try {
        await measurement.save();
        res.status(201).json({ message: 'Measurement added successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getMetrics = async (req, res) => {
    const { field, start_date, end_date } = req.query;
    const filter = {};

    if (start_date && end_date) {
        filter.timestamp = { $gte: new Date(start_date), $lte: new Date(end_date) };
    }

    try {
        const metrics = await Measurement.aggregate([
            { $match: filter },
            {
                $group: {
                    _id: null,
                    avg: { $avg: `$${field}` },
                    min: { $min: `$${field}` },
                    max: { $max: `$${field}` },
                    stdDev: { $stdDevPop: `$${field}` }
                }
            }
        ]);

        if (!metrics.length) {
            return res.status(404).json({ message: 'No data available for metrics calculation' });
        }

        res.json(metrics[0]);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getSymbols = async (req, res) => {
    try {
        const symbols = await Measurement.distinct("symbol");
        res.json(symbols);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

document.getElementById('data-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const symbol = document.getElementById('symbol').value;
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    const chartType = document.getElementById('chartType').value;

    if (!symbol || !startDate || !endDate || !chartType) {
        alert('Please fill in all fields');
        return;
    }

    try {
        const response = await fetch(`/api/measurements?symbol=${symbol}&start_date=${startDate}&end_date=${endDate}`);
        
        if (!response.ok) {
            const errorData = await response.json();
            if (response.status === 404) {
                alert(errorData.message || 'No data available for the selected range');
            } else if (response.status === 500) {
                alert(errorData.message || 'Internal server error. Please try again later.');
            } else {
                alert('Failed to retrieve data. Please check your input and try again.');
            }
            return;
        }

        const data = await response.json();
        console.log('Data received:', data);

        data.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

        const labels = data.map(item => new Date(item.timestamp).toLocaleDateString());
        const values = data.map(item => item.closePrice);

        const ctx = document.getElementById('chart').getContext('2d');
        if (window.stockChart) window.stockChart.destroy();

        const minValue = Math.min(...values);
        const maxValue = Math.max(...values);

        window.stockChart = new Chart(ctx, {
            type: chartType,
            data: {
                labels,
                datasets: [{
                    label: `Close Price of ${symbol.toUpperCase()}`,
                    data: values,
                    borderColor: 'rgba(30, 144, 255, 1)', 
                    backgroundColor: chartType === 'line' ? 'rgba(30, 144, 255, 0.2)' : 'rgba(30, 144, 255, 0.5)',
                    fill: chartType === 'line',  
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: `Close Price of ${symbol.toUpperCase()} over time`
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Close Price (USD)'
                        },
                        beginAtZero: false,
                        min: minValue * 0.95, 
                        max: maxValue * 1.05 
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error fetching data:', error);
        alert('Failed to retrieve data. Please try again.');
    }
});

const express = require('express');
const router = express.Router();
const { getMeasurements, addMeasurement, getSymbols } = require('../controllers/measurementController'); 

router.get('/', getMeasurements);
router.post('/add', addMeasurement);
router.get('/symbols', getSymbols);

module.exports = router;
